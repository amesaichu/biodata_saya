<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>AMEL</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
        <style>
            html, body {
                background-color: #d9d9d9;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }

            .template1 {

            }
        </style>
    </head>
    <body>
        <div class="flex-center position-ref full-height">
            @if (Route::has('login'))
                <div class="top-right links">
                    @auth
                        <a href="{{ url('/home') }}">Home</a>
                    @else
                        <a href="{{ route('login') }}">Login</a>

                        @if (Route::has('register'))
                            <a href="{{ route('register') }}">Register</a>
                        @endif
                    @endauth
                </div>
            @endif
<br><br>
            <div class="content">
                <div class="title m-b-md">
                    BIODATA SAYA
                </div>
                <div style="font-size:20px; "  align="center">
                      <h5>Here my biodata</h5>




<form action="#" style="width: 1000px"class="posisi";>
<fieldset class="h"/>
<table style="width: 980px;">
<tr>
<td rowspan="15" width="250px">
<img src="{{ ('img/1.jpg') }}" width="250px" height="420px"/>
</td>
</tr>
<tr>
<td><b>Nama Lengkap</b></td>
<td>:</td>
<td>Amalya Berliana Saichu </td>
</tr>
<tr>
<td><b>Nama Panggilan</b></td>
<td>:</td>
<td>Amel dongg</td>
</tr>
<tr>
<td><b>Tempat, Tanggal Lahir</b></td>
<td>:</td>
<td>Mojokerto, 07 April 2000</td>
</tr>
<tr>
<td><b>Umur</b></td>
<td>:</td>
<td>19 Tahun</td>
</tr>
<tr>
<td><b>Jenis Kelamin</b></td>
<td>:</td>
<td>Perempuan</td>
</tr>
<tr>
<td><b>Gol. Darah</b></td>
<td>:</td>
<td>O</td>
</tr>
<tr>
<td><b>Agama</b></td>
<td>:</td>
<td>Islam</td>
</tr>
<tr>
<td><b>Alamat</b></td>
<td>:</td>
<td>Dusun Sawo , Desa Puri , Kab Mojokerto </td>
</tr>
<tr>
<td><b>Motto</b></td>
<td>:</td>
<td>Lakukan jangan hanya inginkan</td>
</tr>
<tr>
<td><b>Pekerjaan</b></td>
<td>:</td>
<td>Mahasiswa</td>
</tr>
<tr>
<td><b>Kewarganegaraan</b></td>
<td>:</td>
<td>Indonesia</td>
</tr>
<tr>
<td><b>Social Media</b></td>
<td>:</td>
<td colspan="1" ><a style="text-decoration: none;" target="_parent"><div class="links">
          <a href="https://www.instagram.com/amelschhh/">Instagram</a>
          <a href="https://api.whatsapp.com/send?phone=6289667182086&text=Hallo%20Amel%20Selamat_wkwkwk">Whatsapp</a>
      </div></a>
</td>
</tr>
</table>
</fieldset>
</form>

    </div>
            </div>
        </div>
    </body>
    <br><br>
</html>
